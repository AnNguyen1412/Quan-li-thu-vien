﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibraryManagement
{
    public partial class LibMng : Form
    {
        public LibMng()
        {
            InitializeComponent();
        }

        private void btnDeleteBook_Click(object sender, EventArgs e)
        {
            if (!(txtIDBook.Text == string.Empty))
            {
            SqlConnection connect = new SqlConnection(@"duong dan vo libdatadataset");
            SqlCommand command = new SqlCommand("delete from LibDataDataSet.edata where BookID =' " + this.txtIDBook.Text + "'", connect);
            DataTable dt = new DataTable();
            SqlDataReader myreader;
            try
                {
                    connect.Open();
                    myreader = command.ExecuteReader();
                    MessageBox.Show("Đã xoá thành công", "Library Infomation");
                    while (myreader.Read())
                    {
                    }
                    connect.Close();
                }
            catch (Exception ec)
                {
                    MessageBox.Show(ec.Message);
                }
            }
            else
            {
                MessageBox.Show("Nhập ID sách muốn xoá", "Library Information");
            }
        }
    }
    }
}
